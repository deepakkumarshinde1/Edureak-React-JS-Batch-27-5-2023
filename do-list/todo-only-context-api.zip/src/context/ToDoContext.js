import { createContext, useContext, useState } from "react";

// create a new context
const GlobalTodoContext = createContext({});

// create a provider (component)
export const TodoContextProvider = (props) => {
  let [todoList, setTodoList] = useState([]);
  let [inputValue, setInputValue] = useState("");

  // on change input
  const inputChange = (event) => {
    let { value } = event.target;
    setInputValue(value);
  };

  // save todo
  const saveTodo = (event) => {
    // prevent default submission
    event.preventDefault();

    // check if input value is not empty
    if (inputValue !== "") {
      let newTodo = { title: inputValue, isCompleted: false };
      setTodoList([newTodo, ...todoList]);
      setInputValue("");
    }
  };

  // updateTodoStatus
  const updateTodoStatus = (index) => {
    const _todoList = [...todoList];
    _todoList[index].isCompleted = !_todoList[index].isCompleted;
    //!true === false
    setTodoList(_todoList);
  };
  let store = {
    todoList,
    inputValue,
    inputChange,
    saveTodo,
    updateTodoStatus,
  };

  return (
    <>
      <GlobalTodoContext.Provider value={store}>
        {props.children}
      </GlobalTodoContext.Provider>
    </>
  );
};

// create a custom hook :: we will use it to access a data of context
// useTodoContext is use in other components
export const useTodoContext = () => {
  return useContext(GlobalTodoContext);
};

// useTodoContext == useSelector (Redux)
