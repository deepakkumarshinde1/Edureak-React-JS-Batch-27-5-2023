const ToDoHeader = () => {
  return (
    <>
      <p className="text-center h3 text-primary">Todo List Application</p>
      <hr />
    </>
  );
};

export default ToDoHeader;
