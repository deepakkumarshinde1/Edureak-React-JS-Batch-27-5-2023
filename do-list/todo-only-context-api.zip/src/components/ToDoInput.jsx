import { useTodoContext } from "../context/ToDoContext";

const ToDoInput = () => {
  let { inputValue, inputChange, saveTodo } = useTodoContext();
  return (
    <>
      <form onSubmit={saveTodo}>
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control"
            placeholder="Add a todo item"
            value={inputValue}
            onChange={inputChange}
          />
          <button
            className="input-group-text btn btn-outline-success"
            id="basic-addon1"
          >
            Save Todo
          </button>
        </div>
      </form>
    </>
  );
};

export default ToDoInput;
