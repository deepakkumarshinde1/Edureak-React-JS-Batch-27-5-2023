import ToDoInput from "./ToDoInput";
import ToDoList from "./TodoList";

const ToDo = () => {
  return (
    <>
      <ToDoInput />
      <ToDoList />
    </>
  );
};

export default ToDo;
