import { createSlice } from "@reduxjs/toolkit";

let ProductReducerSlice = createSlice({
  name: "productSlice",
  initialState: {
    productList: [],
    newProduct: {
      product_category: "",
      product_name: "",
      product_price: "",
      product_desc: "",
      product_rating: "",
      product_rating_count: "",
    },
  },
  reducers: {
    saveNewProduct() {},
    inputChange() {},
  },
});

export default ProductReducerSlice.reducer;
